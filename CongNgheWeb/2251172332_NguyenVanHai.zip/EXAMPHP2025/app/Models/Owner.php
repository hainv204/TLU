<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Pet;
class Owner extends Model
{
    protected $fillable = ['name','email','phone','address'];
    public function pets(){
        return $this->hasMany(Pet::class);
    }
}