<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Owner;
class Pet extends Model
{
    protected $fillable = ['name','species','breed','age','owner_id'];
    public function owner(){
        return $this->belongsTo(Owner::class);
    }
}