<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Owner;
use App\Models\Pet;
class PetController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pets = Pet::with('owner')->paginate(6);
        return view('pets.index',compact('pets'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $owners = Owner::all();
        return view('pets.create',compact('owners'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'owner_id' => 'required|exists:owners,id',
            'name' => 'required|string',
            'species' => 'required|string',
            'breed' => 'string|nullable',
            'age' => 'required|min:1',
        ]);
        Pet::create($request->all());
        return redirect()->route('pets.index')->with('success', 'Pet created successfully');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $pet = Pet::findOrFail($id);
        $owners = Owner::all();
        return view('pets.edit', compact('pet', 'owners'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'owner_id' => 'required|exists:owners,id',
            'name' => 'required|string',
            'species' => 'required|string',
            'breed' => 'string|nullable',
            'age' => 'required|min:1',
        ]);
        $pet = Pet::findOrFail($id);
        $pet->update($request->all());
        return redirect()->route('pets.index')->with('success', 'Pet updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $pet = Pet::findOrFail($id);
        $pet->delete();
        return redirect()->route('pets.index')->with('success', 'Pet deleted successfully');
    }
}