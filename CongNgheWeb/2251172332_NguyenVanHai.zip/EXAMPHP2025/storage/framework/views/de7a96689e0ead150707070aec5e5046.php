<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Pet</title>
    <!-- Link CSS Bootstrap5 -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
</head>


<body>
    <form action="<?php echo e(route('pets.store')); ?>" method="POST" enctype="multipart/form-data">
        <!-- CSRF token để bảo vệ khỏi tấn công CSRF -->
        <?php echo csrf_field(); ?>
        <div class="header">
            <h4 class="title">Add Pet</h4>
        </div>
        <div class="body">
            <div>
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div>
                <label for="species" class="form-label">Species</label>
                <input type="text" class="form-control" id="species" name="species" required>
            </div>
            <div>
                <label for="breed" class="form-label">Breed</label>
                <input type="text" class="form-control" id="breed" name="breed">
            </div>
            <div>
                <label for="age" class="form-label">Age</label>
                <input type="numeric" class="form-control" id="age" name="age" required>
            </div>
            <div>
                <label for="owner_id" class="form-label">Owner Name</label>
                <select class="form-control" name="owner_id" id="owner_id">
                    <?php $__currentLoopData = $owners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $owner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($owner->id); ?>"><?php echo e($owner->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div class="footer my-2">
            <button type="submit" class="btn btn-success" name="add" value="Add">Add</button>
        </div>
    </form>
</body>


</html><?php /**PATH D:\EXAMPHP2025\resources\views/pets/create.blade.php ENDPATH**/ ?>