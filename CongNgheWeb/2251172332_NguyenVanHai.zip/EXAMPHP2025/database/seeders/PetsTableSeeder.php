<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use Illuminate\Support\Facades\DB;
use App\Models\Pet;
class PetsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $faker = Faker::create();
        $ownerID = DB::table('owners')->pluck('id');
        for ($i = 0; $i < 20; $i++) {
            Pet::create([
                'owner_id' => $faker->randomElement($ownerID),
                'name' => $faker->name,
                'species' => $faker->firstName,
                'breed' => $faker->lastName,
                'age' => $faker->randomNumber(),
            ]);
        }
    }
}