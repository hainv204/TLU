<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PetController;
//Path index
Route::get('/', [PetController::class, 'index'])->name('pets.index');
//Path view create pets
Route::get('/pets/create', [PetController::class, 'create'])->name('pets.create');
//Path store pets
Route::post('/pets', [PetController::class, 'store'])->name('pets.store');
//Path view edit pets
Route::get('/pets/{id}/edit', [PetController::class, 'edit'])->name('pets.edit');
//Path update pets
Route::put('/pets/{id}', [PetController::class, 'update'])->name('pets.update');
//Path delete pets(confirm modal)
Route::delete('/pets/{id}', [PetController::class, 'destroy'])->name('pets.destroy');